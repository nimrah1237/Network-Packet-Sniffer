from scapy.all import sniff, wrpcap, IP, TCP, UDP, ICMP, ARP, DNS

save_path = r"C:\Users\NCS\Desktop\NetworkPacketSniffer-Scapy\capture.pcapng"

packets = []

def packet_callback(packet):
    packets.append(packet)

    if packet.haslayer(ARP):
        print(f"[ARP]  {packet[ARP].psrc} -> {packet[ARP].pdst}")
    elif packet.haslayer(IP):
        src = packet[IP].src
        dst = packet[IP].dst
        if packet.haslayer(ICMP):
            print(f"[ICMP] {src} -> {dst}")
        elif packet.haslayer(TCP):
            print(f"[TCP]  {src} -> {dst}")
        elif packet.haslayer(UDP):
            if packet.haslayer(DNS) and packet[DNS].qd:
                try:
                    print(f"[DNS]  {src} -> {dst} : {packet[DNS].qd.qname.decode(errors='ignore')}")
                except:
                    print(f"[DNS]  {src} -> {dst}")
            else:
                print(f"[UDP]  {src} -> {dst}")
    else:
        print("[Non-IP] Packet captured")

print("[+] Starting packet capture... Press Ctrl+C to stop.")

try:
    sniff(filter="arp or icmp or tcp or udp", prn=packet_callback, store=False)
except KeyboardInterrupt:
    pass
finally:
    print(f"\n[+] Saving packets to {save_path} ...")
    wrpcap(save_path, packets)
    print(f"[+] Capture saved successfully at: {save_path}")

